import json


import requests

with open('apiCredentials.json') as cred:
    apiCred = json.load(cred)

CLIENT_ID = apiCred["CLIENT_ID"]
CLIENT_SECRET = apiCred["CLIENT_SECRET"]
SCOPE = apiCred["SCOPE"]
URL = 'https://ims-na1.adobelogin.com/ims/token/v3'

def get_authorization():
    b = ('grant_type=client_credentials&'
         'client_id=' + CLIENT_ID + '&'
         'client_secret=' + CLIENT_SECRET + '&'
         'scope=openid,AdobeID,user_management_sdk')
    h = {'Accept': 'application/json',
         'Content-Type': 'application/x-www-form-urlencoded'}
    
    r = requests.request('POST', URL, headers=h, data=b)
    return json.loads(r.text)

if __name__ == '__main__':
   req = get_authorization()
   print(req)
   apiCred["ACCESS_TOKEN"] = req["access_token"]
   newData = json.dumps(apiCred)
   with open('accessToken.json', 'w') as newCred:
       newCred.write(newData)