import json
import requests
import pandas as pd
from add_user_to_group import add_adobe_id

# Authorization
with open('accessToken.json') as file:
    credentials = json.load(file)
# Production User Groups
with open('prodUserGroups.json') as prod:
    prodUserGroups = json.load(prod)
# Development User Groups
with open('devUserGroups.json') as devUG:
    devUserGroups = json.load(devUG)
# Product profiles
with open('productProfiles.json') as pp:
    productProfiles = json.load(pp)

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
# insert sample acct metadata to create; for COUNTRY use 2 letter ISO code
MAIL = ('vaishnavi.todupunuri@verizon.com')
# simulate call or make changes in Admin Console:
IS_TEST = 'true'
# default call management settings
UMAPI_URL = 'https://usermanagement.adobe.io/v2/usermanagement/action/'
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3

# read by default 1st sheet of an excel file
df = pd.read_excel('ACE - Adobe Access Request List.xlsx', sheet_name='Analytics Request OMNI')
data = pd.DataFrame(df)
for index, row in data.iterrows():
    # Provision status is not yet updated
    if row['Provisioning status'] == 'Not yet':
        ps = row['Provisioning status']
        # Check the env to give access
        if row['For which environment do you need access?'] == "Production":
            reqProfiles = row['For which application do you need Adobe Analytics access?'].split(', ')
            # reqProfiles = row['For which application do you need Adobe Analytics access?']
            print(reqProfiles)
            username = row['Official Email ID (which needs to be added)']
            ps = 'Done - '
            for p in prodUserGroups:
                for i in range(0, len(reqProfiles)):
                    if p == reqProfiles[i]:
                        userGroup = prodUserGroups[p]
                        add_adobe_id(username, userGroup)
                        print(username + userGroup)
                        ps += userGroup + ", "
            data.at[index, 'Provisioning status'] = ps[:-2]
        if row['For which environment do you need access?'] == "Development":
            # reqProfiles = row['For which application do you need Adobe Analytics access?']
            reqProfiles = row['For which application do you need Adobe Analytics access?'].split(', ')
            print(reqProfiles)
            username = row['Official Email ID (which needs to be added)']
            ps = 'Done - '
            for r in devUserGroups:
                for i in range(0, len(reqProfiles)):
                    if r == reqProfiles[i]:
                        userGroup = devUserGroups[r]
                        add_adobe_id(username, userGroup)
                        print(username + userGroup)
                        ps += userGroup + ", "
            data.at[index, 'Provisioning status'] = ps[:-2]

data.to_excel("New List.xlsx", index=False)

'''

 if row['For which environment do you need access?'] == "Production":
            reqProfiles = row['For which application do you need Adobe Analytics access?'].split(', ')
            # reqProfiles = row['For which application do you need Adobe Analytics access?']
            print(reqProfiles)
            username = row['Official Email ID (which needs to be added)']
            row['Provisioning status'] = 'Done - '
            for p in prodUserGroups:
                for i in range(0, len(reqProfiles)):
                    if p == reqProfiles[i]:
                        userGroup = prodUserGroups[p]
                        # for j in range(0, len(productProfiles)):
                        for pp in productProfiles:
                            if pp == userGroup:
                                profile = productProfiles[userGroup]
                                # add_adobe_id(username, userGroup, profile)
                                print(username + userGroup + profile)
                                row['Provisioning status'] += userGroup

        if row['For which environment do you need access?'] == "Development":
            # reqProfiles = row['For which application do you need Adobe Analytics access?'].split(',')
            reqProfiles = row['For which application do you need Adobe Analytics access?']
            for r in devUserGroups:
                if r in reqProfiles:
                    userGroup = devUserGroups[r]
                    for userGroup in productProfiles:
                        if pp == userGroup:
                            profile = productProfiles[userGroup]
                            # add_adobe_id(row['username'], userGroup, profile)
                            print(row['username'])

'''
