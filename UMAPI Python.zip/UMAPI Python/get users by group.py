import json
import time
from random import randint

import requests

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = 'eyJhbGciOiJSUzI1NiIsIng1dSI6Imltc19uYTEta2V5LWF0LTEuY2VyIiwia2lkIjoiaW1zX25hMS1rZXktYXQtMSIsIml0dCI6ImF0In0.eyJpZCI6IjE2ODkyMjc2MDcyNDhfZTFmODk1YjQtZGFmYy00ZmQ1LThkZGItNzM2NTY4Y2IxMjE3X3V3MiIsIm9yZyI6Ijc3N0I1NzVFNTU4MjhFQkI3RjAwMDEwMUBBZG9iZU9yZyIsInR5cGUiOiJhY2Nlc3NfdG9rZW4iLCJjbGllbnRfaWQiOiI1Y2MzZTViM2QyYzI0ODkxYTE3ZDhlNmY1NTZkYmIxZCIsInVzZXJfaWQiOiJFOUI0MzhDMTY0QTI3Nzk2MEE0OTVFNUVAdGVjaGFjY3QuYWRvYmUuY29tIiwiYXMiOiJpbXMtbmExIiwiYWFfaWQiOiJFOUI0MzhDMTY0QTI3Nzk2MEE0OTVFNUVAdGVjaGFjY3QuYWRvYmUuY29tIiwiY3RwIjozLCJtb2kiOiI2MGQyZGE4ZSIsImV4cGlyZXNfaW4iOiI4NjQwMDAwMCIsImNyZWF0ZWRfYXQiOiIxNjg5MjI3NjA3MjQ4Iiwic2NvcGUiOiJvcGVuaWQsdXNlcl9tYW5hZ2VtZW50X3NkayxBZG9iZUlEIn0.etSklN9KT4DV7pyDVWUDC-AtTaBLue87fLij09fn-Hcyn9gedYKBOzo8XBCYrQaJ2F4APebMuX53sqTrXhX-dO6SVdXD_RXbhNnA76WkfCfXxHi2TO6l_1QInRuo2s0xX1LOK-kaCes7Pd4xhWNwArXxKqvl-v9o_bGdh7PIeoTIUc5P-vSgCzJn2S8yJPgJvF0JlTbUMbXoKBzgrQoNi_o7D8hqEj7PsRYpUbaiH7uuv83guC5E5X47Yvg5DxsZB3TO8MXEodf_xW89Mao0JWKDcOy0GGtKvSvPxgRmksXzp3eDg74iBFQQLvR-UsTFYuRQEiJ_gansRd8oS1URgg'
CLIENT_ID = '5cc3e5b3d2c24891a17d8e6f556dbb1d'
ORG_ID = '777B575E55828EBB7F000101@AdobeOrg'
# add below an existing user-group or product profile name from Admin Console
GROUP_NAME = 'AA - Basic Access'
UMAPI_URL = 'https://usermanagement.adobe.io/v2/usermanagement/users/'
# direct or indirect members (for PLC query); switch to true for direct membership
DIRECT = '?directOnly=false'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3


def get_users_by_group(group_name):
    """ The function contains logic to resolve the paginated response from the API
    following the lastPage marker.
    Returns a list of dict objects, each one representing one user
    """
    page_index = '0'
    url = UMAPI_URL + ORG_ID + '/' + page_index + '/' + group_name + DIRECT
    method = 'GET'
    done = False
    users_list = []
    # resolve multiple page results
    while not done:
        r = make_call(method, url)
        last_page = r['lastPage']
        if last_page:
            users_list.extend(r['users'])
            done = True
        else:
            users_list.extend(r['users'])
            page_index += 1


    return users_list


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'POST'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'UMAPI timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'UMAPI timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    users = get_users_by_group(GROUP_NAME)
    print(f'{GROUP_NAME} members list:\n')
    print(users)
    if users:
        for i in range(0, len(users)):
            print(users[i])
