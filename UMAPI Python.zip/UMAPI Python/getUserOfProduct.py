import json
import time
from random import randint

import requests

import getUsersOfProductProfile
from getUsersOfProductProfile import get_users_by_productProfile

# Authorization
with open('accessToken.json') as file:
    credentials = json.load(file)
'''
# User List
with open("users.json") as user:
    usersList = json.load(user)
'''

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials['ACCESS_TOKEN']
CLIENT_ID = '5cc3e5b3d2c24891a17d8e6f556dbb1d'
ORG_ID = '777B575E55828EBB7F000101@AdobeOrg'
# add below an existing user-group or product profile name from Admin Console
# GROUP_NAME = 'AA - Basic Access'
PRODUCT_ID = 'C4B312FC780FAFC496EA'
UMAPI_URL = 'https://usermanagement.adobe.io/v2/usermanagement/'
# direct or indirect members (for PLC query); switch to true for direct membership
DIRECT = '?directOnly=false'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3


def get_users_by_product(PRODUCT_ID):
    """ The function contains logic to resolve the paginated response from the API
    following the lastPage marker.
    Returns a list of dict objects, each one representing one user
    """
    page_index = '0'
    url = UMAPI_URL + ORG_ID + '/' + 'products' + '/' + PRODUCT_ID + '/' + 'configurations' + '/'
    method = 'GET'
    done = False
    body = {}
    ''' 
    users_list = []
  # resolve multiple page results
    while not done:
        r = make_call(method, url)
        last_page = r['lastPage']
        if last_page:
            users_list.extend(r['users'])
            done = True
        else:
            users_list.extend(r['users'])
            page_index += 1

'''
    r = make_call(method, url, body)
    print(f'{PRODUCT_ID} members list:\n')
    print(r)
    profiles = r["licenseConfigurations"]
    n = 0
    pl = 0
    if r:
        for i in range(0, len(profiles)):
            pl = pl+1
            users = get_users_by_productProfile(PRODUCT_ID, profiles[i]['id'])
            for j in range(0, len(users)):
                if users[j]:
                    #print(users[j]['firstName'] + ' ' + users[j]['firstName'] + ' - ' + users[j]['username'])
                    n = n+1
                    print(users[j]['username']+' - '+ profiles[i]['name'])
                    #usersList.append(users[j]['username'])


    print("No of profiles = ")
    print(pl)
    print("No of users = ")
    print(n)
    #print(json.dumps(usersList))
    #with open('users.json', 'w') as newUsersList:
        #newUsersList.write(newData)

    # users = get_users_by_productProfile(PRODUCT_ID, profiles[0]['id'])
    # print(users)
    return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'GET'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'UMAPI timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'UMAPI timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    prodConf = get_users_by_product(PRODUCT_ID)
    '''
    print(f'{PRODUCT_ID} members list:\n')
    print(prodConf)
    profiles = prodConf['licenseConfigurations']
    print(profiles[0]['id'])
    users = get_users_by_productProfile(PRODUCT_ID, profiles[0]['id'])
    print(users)
'''
    '''
    if prodConf:
        for i in range(0, len(profiles)):
            users = get_users_by_productProfile(PRODUCT_ID, profiles[i]['id'])
            print(users)
'''
