import json
import time
from random import randint

import requests

# Authorization
with open('accessToken.json') as file:
    credentials = json.load(file)

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = "eyJhbGciOiJSUzI1NiIsIng1dSI6Imltc19uYTEta2V5LWF0LTEuY2VyIiwia2lkIjoiaW1zX25hMS1rZXktYXQtMSIsIml0dCI6ImF0In0.eyJpZCI6IjE2OTg3MzY4MDI1MDNfOTUxOTE4YTktZjA0NS00NzZkLWJhMjAtOThkMzU2NzJjMTJiX3V3MiIsIm9yZyI6Ijc3N0I1NzVFNTU4MjhFQkI3RjAwMDEwMUBBZG9iZU9yZyIsInR5cGUiOiJhY2Nlc3NfdG9rZW4iLCJjbGllbnRfaWQiOiJkOTA5ZWNkYjg5Nzg0OGNkOTJlZGIyZjYwMTA1ZGE3NyIsInVzZXJfaWQiOiI2OTRDMUU1RDY1M0Y4OUMwMEE0OTVDQzlAdGVjaGFjY3QuYWRvYmUuY29tIiwiYXMiOiJpbXMtbmExIiwiYWFfaWQiOiI2OTRDMUU1RDY1M0Y4OUMwMEE0OTVDQzlAdGVjaGFjY3QuYWRvYmUuY29tIiwiY3RwIjozLCJtb2kiOiI5MzllZTg2MiIsImV4cGlyZXNfaW4iOiI4NjQwMDAwMCIsInNjb3BlIjoib3BlbmlkLHNlc3Npb24sQWRvYmVJRCxyZWFkX29yZ2FuaXphdGlvbnMsYWRkaXRpb25hbF9pbmZvLnByb2plY3RlZFByb2R1Y3RDb250ZXh0IiwiY3JlYXRlZF9hdCI6IjE2OTg3MzY4MDI1MDMifQ.J1gUJKopF7poeT6lIYso9tQC03R-7KPGeX8ao2D8JvUWlZuAtIQt83FD3ALJTVWgF04j9QRgJzkVZuLH3eHZU40oH3a9JONQUWqdlrOqvqq6RAg1HzaJNXxKwJAFM5skrHFvA5Alms-w49UXdZJSezr6gcGxB8vNeBC_nGTIkRYmEmO-3N0kpK3nEKkBxnOLWOU53qatRsbmWevcsfuifzEvm2sb6hxkkHjlADEJO5FawjHHrFvVAMkplKfVmWMRIXbUQgGJvNh55iLsp2oxyhKD8uYuUgvgyxbtlDOY0ZUL4EsvO9cPTYqVcJYdguuM9cjFD0jiwRP6dnULNas8dw"
CLIENT_ID = "d909ecdb897848cd92edb2f60105da77"
ORG_ID = "777B575E55828EBB7F000101@AdobeOrg"
# add below an existing account's email from Admin Console
USER_EMAIL = 'vaishnavi.todupunuri@verizon.com'
URL = 'https://platform.adobe.io/data/core/ups/export/jobs'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3


def get_user_info():
    url = URL
    method = 'POST'
    body = [{

        "filter": {
            "segments": [
                {
                    "segmentId": "86f0cff5-d191-4655-8610-a6e23cdc9c8a",
                    #"segmentNs": "ups",
                    "status": [
                        "realized"
                    ]
                }
            ],

            "emptyProfiles": True
        },

        "destination": {
            "datasetId": "653f85dc8910cb28d22c1a11",
            "segmentPerBatch": False
        },
        "schema": {
            "name": "_xdm.context.profile"
        },
        "evaluationInfo": {
            "segmentation": True
        }
    }]
    r = make_call(method, url, body)
    return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN,
         'x-gw-ims-org-id': ORG_ID}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'POST'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'UMAPI timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'UMAPI timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    users = get_user_info()
    print(users)
