# import pandas lib as pd
import pandas as pd
from add_user_to_group import add_adobe_id
# read by default 1st sheet of an excel file
df = pd.read_excel('sample users.xlsx')
for index, row in df.iterrows():
    if row['notes'] == 'no':
        # add_adobe_id(row['username'], 'CJA Reporting', 'CJA Reporting Team')
        print(row['username'])
