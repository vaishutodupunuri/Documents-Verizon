import json
from typing import Any

import getMetricDefinition
import time
from random import randint

import segForCM
from getSegmentDefinition import get_segment
import requests
# import segForCM
import subprocess

# Authorization
with open('accessToken.json') as file:
    credentials = json.load(file)
# AA - CJA Mapping
with open('mapping.json') as map:
    mapping = json.load(map)
# AA - CJA Calc Metric IDs Mapping
with open('metricIDs.json') as met:
    metricID = json.load(met)
# AA - CJA Segment IDs Mapping
with open('segmentIDs.json') as seg:
    segmentID = json.load(seg)
# AA - CJA Metric Names Mapping
with open('metricNames.json') as metNames:
    metricNames = json.load(metNames)
# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
COMPANY_ID = credentials["COMPANY_ID"]
METRIC_DEF = getMetricDefinition.get_metric('cm300000385_616da8540525f967ec4b8030')
DVID = 'dv_63d7d662010d9335c623e1e3'
DATANAME = "VZ OMNI - Digital"
API_URL = 'https://cja.adobe.io/calculatedmetrics'
migrateID = ''
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY =3

def create_metric():
    global metricID
    temp_def = METRIC_DEF['definition']
    def_str = json.dumps(temp_def)
    # Replace AA fields with CJA fields
    for i in reversed(mapping):
        if i in def_str:
            value = mapping[i]
            print(value)
            def_str = def_str.replace(i, value)
            temp_def = json.loads(def_str)

    segments = METRIC_DEF['compatibility']['segments']
    print(segments)
    for j in segments:
        if j not in segmentID:
            migrateID = str(j)
            new = segForCM.create_segment(migrateID)
            if 'migrated' not in new:
                old = migrateID
                segmentID[old] = new['id']
                with open("segmentIDs.json", 'w') as json_file:
                    json.dump(segmentID, json_file)
            print(new)

    for z in segmentID:
        if z in def_str:
            value = segmentID[z]
            print(value)
            def_str = def_str.replace(z, value)
            temp_def = json.loads(def_str)

    url = API_URL
    method = 'POST'
    body = {
        "dataId": DVID,
        "name": METRIC_DEF['name'],
        "description": METRIC_DEF['description'],
        "polarity": METRIC_DEF['polarity'],
        "precision": METRIC_DEF['precision'],
        "type": METRIC_DEF['type'],
        "definition": temp_def,
        "dataName": DATANAME
    }
    if METRIC_DEF['id'] not in reversed(metricNames):
        old = METRIC_DEF['id']
        metricNames[old] = METRIC_DEF['name']
        with open("metricNames.json", 'w') as met_json:
            json.dump(metricNames, met_json)

    if METRIC_DEF['id'] in reversed(metricID):
        return ("The calculated metric " + METRIC_DEF['name'] + " is already migrated to CJA")
    else:
        r = make_call(method, url, body)
        return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-gw-ims-org-id': ORG_ID,
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'POST'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'API timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'API timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    metric = create_metric()
    print(metric)
    if 'migrated' not in metric:
        oldID = str(METRIC_DEF['id'])
        metricID[oldID] = metric['id']
        with open("metricIDs.json", 'w') as json_file:
            json.dump(metricID, json_file)

