import json
import time
from random import randint
import math

import requests
import segForCM
import transferAssets

with open('accessToken.json') as file:
    credentials = json.load(file)
# AA - CJA Migrated Segment IDs with Login IDs Mapping
with open('segmentIDwithUsers.json') as userLogins:
    loginNames = json.load(userLogins)
# All segment list
with open('allSegments.json') as allSeg:
    allSegments = json.load(allSeg)
# Rob's Segment List
with open('robSegments.json') as robSeg:
    robSegments = json.load(robSeg)
# AA - CJA Segment IDs Mapping
with open('segmentIDs.json') as seg:
    segmentID = json.load(seg)

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
COMPANY_ID = credentials["COMPANY_ID"]

API_URL = 'https://analytics.adobe.io/api/'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3
i = 0


def get_all_segments(i):
    url = API_URL + COMPANY_ID + '/segments/?rsids=verizontelecomomni&locale=en_US&filterByPublishedSegments=all&limit=1000&sortDirection=DESC&sortProperty=modified_date&expansion=reportSuiteName,ownerFullName,modified,tags,compatibility,definition,categories&includeType=all&page=' + str(
        i)
    method = 'GET'
    r = make_call(method, url)

    return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'GET'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'API timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'API timeout... giving up after {MAX_RETRIES} attempts.')


def segment_loop(segmentsResult):
    print("segment loop function")
    print(segmentsResult)

    for h in range(0, len(segmentsResult['content'])):
        # segID = segmentsResult['content'][h]['id']
        print(segmentsResult['content'][h]['owner']['login'])
        allSegments[h]['login'] = segmentsResult['content'][h]['owner']['login']
        allSegments[h]['id'] = segmentsResult['content'][h]['id']
        allSegments[h]['modified'] = segmentsResult['content'][h]['modified']
        with open("allSegments.json", 'w') as json_file:
            json.dump(allSegments, json_file)

    return


if __name__ == '__main__':
    segments = get_all_segments(i)
    ##for i in range(0, len(segments)):
    # print(segments)
    # print(len(segments['content']))
    # segment_loop(segments)
    print('length')
    print(len(segments['content']))
    segCount = 0
    segLen = math.ceil(segments['totalElements'] / 1000)
    print(segLen)
    # Loop for total pages
    for t in range(0, segLen):
        segments = get_all_segments(t)
        # loop for segments in each page
        for h in range(0, len(segments['content'])):
            if (segments['content'][h]['owner']['login'] == 'pranitha.katta@verizon.com'):
                # if (segments['content'][h]['owner']['login'] == 'vaishnavi.todupunuri@verizon.com'):
                segCount = segCount + 1
                segID = segments['content'][h]['id']
                print(segID)
                allSegments['login'] = segments['content'][h]['owner']['login']
                allSegments['id'] = segments['content'][h]['id']
                allSegments['modified'] = segments['content'][h]['modified']
                if segID not in ('s300000385_5ece981e4618f60550fc454e', 's300000385_5eea72aabe6bf2599d218e24',
                                 's300000385_5eea7338e7a40d345385ca1e', 's300000385_5f68cd63120ebf5d978b7689',
                                 's300000385_5f68d56bc945643387bb6b46', 's300000385_6182c857ff0cf80c2bcaf144',
                                 's300000385_619d3f533590775f362bf2a6', 's300000385_619d59fc1e66e152fd7ef770',
                                 's300000385_61aa95c58626233f6d4a3705', 's300000385_61aa95577c055273356969e5',
                                 's300000385_61aa96d34281ad1b8bbe7bde', 's300000385_61aa97301d7a3c093f01d49a',
                                 's300000385_61aa97646271c551210c7e88', 's300000385_61ae77b32e2d5e182103a11f',
                                 's300000385_61c102613680840e62af9cb3', 's300000385_6195709e9e44fa26fc534c53',
                                 's300000385_631b56ff300dc0444eef11ee', 's300000385_66a3a52c2497d16ec5934fa7',
                                 's300000385_66a3a441fca6ff3942763393', 's300000385_636ea61206a0473c5b3c4b2b',
                                 's300000385_62b49de75eaed97f03053e51', 's300000385_62b4b61fe88e88202048d582'):
                    new = segForCM.create_segment(segID)
                    # robSegments[segID] = new['id']
                    if 'migrated' not in new:
                        segID = segments['content'][h]['id']
                        segmentID[segID] = new['id']
                        robSegments[segID] = new['id']
                        with open("segmentIDs.json", 'w') as json_file:
                            json.dump(segmentID, json_file)
                        with open("allSegments.json", 'w') as segments_file:
                            json.dump(allSegments, segments_file)
                        #with open("robSegments.json", "w") as robSeg:
                            #json.dump(robSegments, robSeg)
                    #transfer = transferAssets.transferAsset(segID)

        print(segCount)

    # for j in range(i, segLen):
    # i = i + 1
    # segments = get_all_segments(i)
    # print(segments)
    # get a particular users segments
    # for t in range(0, segments['numberOfElements']):
    # if segments['content'][t]['owner']['login'] == 'robert.angley@verizon.com':
    # print(segments['content'][t]['id'])
