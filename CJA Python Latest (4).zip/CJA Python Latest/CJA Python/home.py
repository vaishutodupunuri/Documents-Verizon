import unicodedata
import getAllSegments


def display():
    ALL_SEGMENTS = getAllSegments.get_all_segments()
    columns = ["#", "Segment"]
    print(ALL_SEGMENTS)
    table_head = f"<thead>\n<tr><th>{'</th><th>'.join(columns)}</th></tr>\n</thead>"
    table_body = "\n<tbody>\n"
    for i in range(0, len(ALL_SEGMENTS['content'])):
        for s in ALL_SEGMENTS['content'][i]:
            if s == 'name':
                segment_data = [f"{i}.", ALL_SEGMENTS['content'][i][s]]
                table_body += f"<tr><td>{'</td><td>'.join(segment_data)}</td></tr>\n"

    table_body += "</tbody>\n"

    return (f"<table>\n{table_head}{table_body}</table>")


if __name__ == '__main__':
    html = display()
    print(html)
