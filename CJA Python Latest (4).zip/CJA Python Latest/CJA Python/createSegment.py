import json
import time
from random import randint
from typing import Dict, Any

from getSegmentDefinition import get_segment
import requests

with open('accessToken.json') as file:
    credentials = json.load(file)

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
COMPANY_ID = credentials["COMPANY_ID"]
# SEGMENT_DEF = getSegmentDefinition.get_segment('s300000385_5dc03b545965262cef7bfaf3')
SEGMENT_DEF = get_segment('s300000385_64c257d76618094eddd32f01')
DVID = 'dv_63d7d662010d9335c623e1e3'
DATANAME = "OMNI Prod VZW"
API_URL = 'https://cja.adobe.io/filters'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3


def create_segment():
    temp = SEGMENT_DEF['definition']
    print(temp)
    SEGMENT_DEF['definition']['container']['pred']['val']['name'] = 'variables/_verizon.vzdl.page.channelSession'
    print(SEGMENT_DEF['definition']['container']['pred']['val']['name'])
    url = API_URL
    method = 'POST'
    body = {
        "name":SEGMENT_DEF['name'],
        "report_suite":DVID,
        "definition":SEGMENT_DEF['definition'],
        "dataId":DVID,
        "dataName":DATANAME
    }

    r = make_call(method, url, body)
    return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-gw-ims-org-id': ORG_ID,
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'POST'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'API timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'API timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    segment = create_segment()
    print(segment)


