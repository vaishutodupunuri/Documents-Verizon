import json
from typing import Any

import getMetricDefinition
import time
from random import randint
from getWorkspaceReport import get_analyticsWorkspace
import segForCM
import cmForProject
from dateRangesAutomation import create_dateRange
from getSegmentDefinition import get_segment
import requests
# import segForCM
import subprocess

# Authorization
with open('accessToken.json') as file:
    credentials = json.load(file)
# AA - CJA Mapping
with open('mapping.json') as map:
    mapping = json.load(map)
# AA - CJA Calc Metric IDs Mapping
with open('metricIDs.json') as met:
    metricID = json.load(met)
# AA - CJA Segment IDs Mapping
with open('segmentIDs.json') as seg:
    segmentID = json.load(seg)
# AA - CJA Report IDs Mapping
with open('reportIDs.json') as rep:
    reportID = json.load(rep)
# AA- CJA Date ranges Mapping
with open('dateRangeIDs.json') as dateR:
    dateID = json.load(dateR)
# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
COMPANY_ID = credentials["COMPANY_ID"]
REPORT_DEF = get_analyticsWorkspace('68f8005f698da02c5695b297')
PROJECTID = '68f8005f698da02c5695b297'
DVID = 'dv_63d7d662010d9335c623e1e3'
DATANAME = "VZ OMNI - Digital"
API_URL = 'https://cja.adobe.io/projects'
migrateID = ''
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3


def create_report():
    global compID
    # REPORT_DEF = get_analyticsWorkspace(PROJECTID)
    temp_def = REPORT_DEF['definition']
    def_str = json.dumps(temp_def)
    panels = REPORT_DEF['definition']['workspaces'][0]['panels']
    old_panels = REPORT_DEF['definition']['workspaces'][0]['panels']
    # Replace AA fields with CJA fields
    for i in reversed(mapping):
        if i in def_str:
            value = mapping[i]
            print(value)
            def_str = def_str.replace(i, value)
            temp_def = json.loads(def_str)

    p = 0
    q = 0
    for p in range(0, len(panels)):
        for q in range(0, len(panels[p]['segmentGroups'])):
            for r in panels[p]['segmentGroups'][q]['componentOptions']:
                if r['component']['type'] == 'Segment':
                    if r['component']['id'] not in segmentID:
                        compID = r['component']['id']
                        new_seg = segForCM.create_segment(compID)
                        if 'migrated' not in new_seg:
                            old = compID
                            segmentID[old] = new_seg['id']
                            with open("segmentIDs.json", 'w') as s_file:
                                json.dump(segmentID, s_file)
                        print(new_seg)

    p = 0
    q = 0
    i = 0
    for p in range(0, len(panels)):
        for q in range(0, len(panels[p]['subPanels'])):
            if panels[p]['subPanels'][q]['reportlet']['type'] == "FreeformReportlet":
                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes']:
                        if r['component']['type'] == "CalculatedMetric" and r['component']['id'] not in metricID:
                            compID = r['component']['id']
                            print(r['component']["__metaData__"]['name'])
                            new_met = cmForProject.create_metric(compID)
                            if 'migrated' not in new_met:
                                old = compID
                                metricID[old] = new_met['id']
                                with open("metricIDs.json", 'w') as m_file:
                                    json.dump(metricID, m_file)
                            print(new_met)
                        if r['component']['type'] == "Segment" and r['component']['id'] not in segmentID:
                            compID = r['component']['id']
                            print(r['component']["__metaData__"]['name'])
                            new_seg = segForCM.create_segment(compID)
                            if 'migrated' not in new_seg:
                                old = compID
                                segmentID[old] = new_seg['id']
                                with open("segmentIDs.json", 'w') as s_file:
                                    json.dump(segmentID, s_file)
                            print(new_seg)
                    node = panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][i]
                    while node['nodes']:
                        for d in range(0, len(node['nodes'])):
                            for r in node['nodes']:
                                if r['component']['type'] == "CalculatedMetric" and r['component']['id'] not in metricID:
                                    compID = r['component']['id']
                                    print(r['component']["__metaData__"]['name'])
                                    new_met = cmForProject.create_metric(compID)
                                    if 'migrated' not in new_met:
                                        old = compID
                                        metricID[old] = new_met['id']
                                        with open("metricIDs.json", 'w') as m_file:
                                            json.dump(metricID, m_file)
                                    print(new_met)
                                if r['component']['type'] == "Segment" and r['component']['id'] not in segmentID:
                                    compID = r['component']['id']
                                    print(r['component']["__metaData__"]['name'])
                                    new_seg = segForCM.create_segment(compID)
                                    if 'migrated' not in new_seg:
                                        old = compID
                                        segmentID[old] = new_seg['id']
                                        with open("segmentIDs.json", 'w') as s_file:
                                            json.dump(segmentID, s_file)
                                    print(new_seg)
                        if node['nodes'][0]['nodes']:
                            node = node['nodes'][0]
                        else:
                            break
                    else:
                        pass

            if panels[p]['subPanels'][q]['reportlet']['type'] == "Fallout":
                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['checkpoints'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['checkpoints']:
                        for j in range(0, len(r['items'])):
                            if r['items'][j]['type'] == 'Segment' and r['items'][j]['id'] not in segmentID:
                                print(r['items'])
                                compID = r['items'][j]['id']
                                new_seg = segForCM.create_segment(compID)
                                if 'migrated' not in new_seg:
                                    old = compID
                                    segmentID[old] = new_seg['id']
                                    with open("segmentIDs.json", 'w') as s_file:
                                        json.dump(segmentID, s_file)
                                print(new_seg)
                if len(panels[p]['subPanels'][q]['reportlet']['segments']) != 0:
                    for pl in range(0, len(panels[p]['subPanels'][q]['reportlet']['segments'])):
                        for z in (panels[p]['subPanels'][q]['reportlet']['segments'][pl]):
                            if z['type'] == 'Segment' and z['id'] not in segmentID:
                                compID = z['id']
                                new_seg = segForCM.create_segment(compID)
                                if 'migrated' not in new_seg:
                                    old = compID
                                    segmentID[old] = new_seg['id']
                                    with open("segmentIDs.json", 'w') as s_file:
                                        json.dump(segmentID, s_file)
                                print(new_seg)

            else:
                pass

            if panels[p]['subPanels'][q]['reportlet']['type'] == "VennReportlet":
                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['metrics'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['metrics']:
                        if r['type'] == 'CalculatedMetric' and r['id'] not in metricID:
                            compID = r['id']
                            new_met = cmForProject.create_metric(compID)
                            if 'migrated' not in new_met:
                                old = compID
                                metricID[old] = new_met['id']
                                with open("metricIDs.json", 'w') as m_file:
                                    json.dump(metricID, m_file)
                            print(new_met)
                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['segments'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['segments']:
                        if r['type'] == 'CalculatedMetric' and r['id'] not in segmentID:
                            compID = r['id']
                            new_seg = segForCM.create_segment(compID)
                            if 'migrated' not in new_seg:
                                old = compID
                                segmentID[old] = new_seg['id']
                                with open("segmentIDs.json", 'w') as s_file:
                                    json.dump(segmentID, s_file)
                            print(new_seg)
            else:
                pass

            if panels[p]['subPanels'][q]['reportlet']['type'] == "CohortReportlet":
                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['inclusionCriteria']['segments'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['inclusionCriteria']['segments']:
                        if r['id'] not in segmentID:
                            compID = r['id']
                            new_seg = segForCM.create_segment(compID)
                            if 'migrated' not in new_seg:
                                old = compID
                                segmentID[old] = new_seg['id']
                                with open("segmentIDs.json", 'w') as s_file:
                                    json.dump(segmentID, s_file)
                            print(new_seg)

                for i in range(0, len(panels[p]['subPanels'][q]['reportlet']['returnCriteria']['segments'])):
                    for r in panels[p]['subPanels'][q]['reportlet']['returnCriteria']['segments']:
                        if r['id'] not in segmentID:
                            compID = r['id']
                            new_seg = segForCM.create_segment(compID)
                            if 'migrated' not in new_seg:
                                old = compID
                                segmentID[old] = new_seg['id']
                                with open("segmentIDs.json", 'w') as s_file:
                                    json.dump(segmentID, s_file)
                            print(new_seg)
            else:
                pass
            '''
            for dr in range(0, len(panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'])):
                if panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr] != '' and panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['component']['type'] == "DateRange":
                        for r in panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['component']:
                            if r['id'] not in dateID:
                                drID = r['id']
                                new_date = create_dateRange(drID)
                                if 'migrated' not in new_date:
                                    old = drID
                                    dateID[old] = new_date['id']
                                    with open("dateRangeIDs.json", 'w') as d_file:
                                        json.dump(dateID, d_file)
                                print(new_date)
                for dr1 in range(0, len(panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'])):
                    if panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'][dr1] != '' and panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes']['nodes'][dr]['nodes'][dr1]['component']['type'] == "DateRange":
                        for r in panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'][dr1]['component']:
                            if r['id'] not in dateID:
                                drID = r['id']
                                new_date = create_dateRange(drID)
                                if 'migrated' not in new_date:
                                    old = drID
                                    dateID[old] = new_date['id']
                                    with open("dateRangeIDs.json", 'w') as d_file:
                                        json.dump(dateID, d_file)
                                print(new_date)
                    for dr2 in range(0, len(panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'][dr1]['nodes'])):
                        if panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'][dr1]['nodes'][dr2] != '' and panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes']['nodes'][dr]['nodes'][dr1]['nodes'][dr2]['component']['type'] == "DateRange":
                            for r in panels[p]['subPanels'][q]['reportlet']['columnTree']['nodes'][dr]['nodes'][dr1]['nodes'][dr2]['component']:
                                if r['id'] not in dateID:
                                    drID = r['id']
                                    new_date = create_dateRange(drID)
                                    if 'migrated' not in new_date:
                                        old = drID
                                        dateID[old] = new_date['id']
                                        with open("dateRangeIDs.json", 'w') as d_file:
                                            json.dump(dateID, d_file)
                                    print(new_date)
                                    '''

    for z in segmentID:
        if z in def_str:
            value = segmentID[z]
            print(value)
            def_str = def_str.replace(z, value)
            temp_def = json.loads(def_str)

    for z in metricID:
        if z in def_str:
            value = metricID[z]
            print(value)
            def_str = def_str.replace(z, value)
            temp_def = json.loads(def_str)

    for p in range(0, len(panels)):
        temp_def['workspaces'][0]['panels'][p]['reportSuite']['id'] = DVID
        temp_def['workspaces'][0]['panels'][p]['reportSuite']['__metaData__']['rsid'] = DVID
        temp_def['workspaces'][0]['panels'][p]['reportSuite']['__metaData__']['name'] = DATANAME

    url = API_URL
    method = 'POST'
    body = {
        "dataId": DVID,
        "name": REPORT_DEF['name'],
        "description": REPORT_DEF['description'],
        "type": REPORT_DEF['type'],
        "definition": temp_def,
        "dataName": DATANAME
    }
    if REPORT_DEF['id'] in reversed(reportID):
        return ("The report " + REPORT_DEF['name'] + " is already migrated to CJA")
    else:
        r = make_call(method, url, body)
        return r


def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-gw-ims-org-id': ORG_ID,
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'POST'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'API timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'API timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    report = create_report()
    print(report)
    if 'migrated' not in report:
        oldID = str(REPORT_DEF['id'])
        reportID[oldID] = report['id']
        with open("reportIDs.json", 'w') as json_file:
            json.dump(reportID, json_file)
