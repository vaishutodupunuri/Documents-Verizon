# importing subprocess module
import subprocess
from getImsUserid import get_user
import segForCM
import json
import time
from random import randint
from datetime import datetime






'''
# AA - CJA Segment IDs Mapping
with open('segmentIDs.json') as seg:
    segmentID = json.load(seg)
imsID = subprocess.run(["python", "getImsUserid.py"])
imsID = get_user('prathap.karunakaran@verizon.com')
print(imsID)
new = segForCM.create_segment('s300000385_67ee563d23e8f953b87b9bd9')
print(new)
if 's300000385_64b67c45992564330a4df733' not in reversed(segmentID):
    new = segForCM.create_segment('s300000385_64b67c45992564330a4df733')
else:
    new = segmentID['s300000385_64b67c45992564330a4df733']
print(new)


date_string = "2025-02-25T12:44:09Z"
date_object = datetime.fromisoformat(date_string.replace('Z', '+00:00'))
print(date_object.date())
'''