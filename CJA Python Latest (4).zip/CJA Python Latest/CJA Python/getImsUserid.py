import json
import time
from random import randint
import math

import requests

with open('accessToken.json') as file:
    credentials = json.load(file)
# AA - CJA Migrated Segment IDs with Login IDs Mapping
with open('segmentIDwithUsers.json') as userLogins:
    loginNames = json.load(userLogins)
# All segment list
with open('allSegments.json') as allSeg:
    allSegments = json.load(allSeg)

# access token obtained via OAuth S2S workflow
ACCESS_TOKEN = credentials["ACCESS_TOKEN"]
CLIENT_ID = credentials["CLIENT_ID"]
ORG_ID = credentials["ORG_ID"]
COMPANY_ID = credentials["COMPANY_ID"]

API_URL = 'https://analytics.adobe.io/api/'
# default call management settings
MAX_RETRIES = 4
TIMEOUT = 120.0
RANDOM_MAX = 5
FIRST_DELAY = 3
i = 0
#email = 'vaishnavi.todupunuri@verizon.com'
global ims

def get_all_users(p, n):
    url = 'https://cja.adobe.io/configuration/orgs/users?limit=1000&page=' + p
    method = 'GET'
    r = make_call(method, url)

    return r


def get_user(email):

    users = get_all_users('0', email)
    for u in range(0, users['totalPages']):
        print("u:" + str(u))
        users = get_all_users(str(u), email)
        #print(users)
        for j in range(0, len(users['content'])):
            if users['content'][j]['email'] == email:
                ims = users['content'][j]['id']
                print(ims)
                return ims






def make_call(method, url, body={}):
    """
    call manager function with retry mechanism which returns
    the API response as a dict
    """
    retry_wait = 0
    h = {'Accept': 'application/json',
         'x-api-key': CLIENT_ID,
         'Authorization': 'Bearer ' + ACCESS_TOKEN,
         'x-gw-ims-org-id': ORG_ID}
    if body:
        h['Content-type'] = 'application/json'
        body = json.dumps(body)
        method = 'GET'
    for num_attempt in range(1, MAX_RETRIES + 1):
        try:
            print(f'Calling {method} {url}\n{body}')
            r = requests.request(method, url, data=body, headers=h, timeout=TIMEOUT)
            if r.status_code == 200:
                return json.loads(r.text)
            elif r.status_code in [429, 502, 503, 504]:
                print(f'API timeout... (code {r.status_code} on try {num_attempt})')
                if retry_wait <= 0:
                    delay = randint(0, RANDOM_MAX)
                    retry_wait = (pow(2, num_attempt - 1) * FIRST_DELAY) + delay
                if 'Retry-After' in r.headers.keys():
                    retry_wait = int(r.headers['Retry-After']) + 1
            else:
                print(f'Unexpected HTTP Status: {r.status_code}: {r.text}')
                return
        except Exception as e:
            print(f'Exception encountered:\n {e}')
            return
        if num_attempt < MAX_RETRIES:
            if retry_wait > 0:
                print(f'Next retry in {retry_wait} seconds...')
                time.sleep(retry_wait)
    print(f'API timeout... giving up after {MAX_RETRIES} attempts.')


if __name__ == '__main__':
    user = get_user('vaishnavi.todupunuri@verizon.com')
    print(user)
    # print(users)
    # print('totalELements: '+str(math.ceil(users['totalElements'] / 1000)))

    # for j in range(i, segLen):
    # i = i + 1
    # segments = get_all_segments(i)
    # print(segments)
    # get a particular users segments
    # for t in range(0, segments['numberOfElements']):
    # if segments['content'][t]['owner']['login'] == 'robert.angley@verizon.com':
    # print(segments['content'][t]['id'])
