import requests
from bs4 import BeautifulSoup
import openpyxl
import json


url = 'https://www.verizon.com'
reqs = requests.get(url)
soup = BeautifulSoup(reqs.text, 'html.parser')

urls = []
print('LINKS')

with open("links.json", "w", encoding="utf-8") as f:
	f.write("[")
	attributes = {}
	for link in soup.find_all('a'):
		attributes['link'] = link.get('href')
		attributes['data-track'] = link.get('data-track')
		attributes['aria-label'] = link.get('aria-label')
		print(attributes)
		json.dump(attributes, f)
		f.write(",")
	f.write("{}]")









