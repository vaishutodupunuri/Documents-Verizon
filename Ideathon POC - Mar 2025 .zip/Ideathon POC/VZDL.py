# Import the required modules
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import time
import json
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

# Main Function
if __name__ == "__main__":

    # Enable Performance Logging of Chrome.
    desired_capabilities = DesiredCapabilities.CHROME
    desired_capabilities["goog:loggingPrefs"] = {"performance": "ALL"}

    # Create the webdriver object and pass the arguments
    options = webdriver.ChromeOptions()

    # Chrome will start in Headless mode
    options.add_argument('headless')

    # Ignores any certificate errors if there is any
    options.add_argument("--ignore-certificate-errors")

    # Startup the chrome webdriver with executable path and
    # pass the chrome options and desired capabilities as
    # parameters.
    service = ChromeService(executable_path=ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service)
    urls = {
        "https://www.verizon.com/",
        "https://s360-qa1east.vzwcorp.com/s360/convoiq"
    }
    with open("network_log.json", "w", encoding="utf-8") as f:
        f.write("[")
        for url in urls:
            driver.get(url)
            # Send a request to the website and let it load

            print('Opened successfully')
            # Sleeps for 10 seconds
            time.sleep(10)

            # Gets all the logs from performance in Chrome
            logs = driver.get_log("performance")
            result = {}
            try:
                result = driver.execute_script("return vzdl;")
            except:
                print("An exception occurred")

            if len(result) != 0:
                title = result['page']['name'] or driver.execute_script("return document.title;")
                pageURL = result['page']['url'] or url
                sourceChannel = result['page']['sourceChannel']
                displayChannel = result['page']['displayChannel']
                channel = result['page']['channel']
            else:
                title = driver.execute_script("return document.title;")
                pageURL =  url
                channel = url.split(".com")[1]
                #if sourceChannel == '':
                if "verizon.com" in url:
                        sourceChannel = 'vzw'
                        displayChannel = 'vzw'
                elif "vzwcorp.com" in url:
                        sourceChannel = 'covoiq'
                        displayChannel = 'convoiq'

            sample = {
                        'kpiName': 'pageView',
                        'kpiAttributes': {
                            'page': {
                                'name': title,
                                'url': pageURL,
                                'sourceChannel': sourceChannel,
                                'displayChannel': displayChannel,
                                'channel': channel

                            }
                        }
                    }
            print(sample)
            json.dump(sample, f)
            f.write(",")
        f.write("{}]")
        # print(result)



    print("Quitting Selenium WebDriver")
    driver.quit()