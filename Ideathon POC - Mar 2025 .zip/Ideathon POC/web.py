import requests
from bs4 import BeautifulSoup
import csv

URL = 'https://www.verizon.com'
r = requests.get(URL)
##print(r.content)

soup = BeautifulSoup(r.text, 'html.parser')
##print(soup.prettify())
quotes = []  # a list to store quotes

for row in soup.find_all('a'):
    quote = {}

    quote['url'] = row.get('href')
    quote['img'] = row.get('data-track')

    quotes.append(quote)

    filename = 'inspirational_quotes.csv'
    with open(filename, 'w') as f:
        w = csv.writer(f)
        ##w = csv.DictWriter(f, ['href', 'data-track'])
    # w.writeheader()
    for quote in quotes:
        w.writerow(quote)

print(quotes)
